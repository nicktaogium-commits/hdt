# Ghi chú sửa lỗi NetBeans GUI Builder

## Đã chỉnh trong bản này
- Đồng bộ lại `OrderFrame.java` và `OrderFrame.form`: tên biến, component, kích thước và sự kiện đã khớp nhau.
- Chuyển phần khởi tạo model bảng và trang trí giao diện của `OrderFrame` ra ngoài khối mã do GUI Builder quản lý.
- Chặn các thao tác truy vấn MySQL khi NetBeans dựng giao diện ở Design time trong `OrderFrame`, `MenuFrame`, `TableFrame`, `HistoryFrame`.
- Chỉ cài đặt hỗ trợ co giãn khi chạy ứng dụng, không cài listener trong Design time.
- Đồng bộ thuộc tính `resizable` của `LoginFrame.form` với `LoginFrame.java`.

## Kết quả kiểm tra tự động
- Sáu file `.form` hiện có đều đọc được dưới dạng XML.
- Các tên component và event handler trong từng `.form` đều có khai báo tương ứng trong Java.
- Không tìm thấy RGB literal hoặc kênh màu trong `.form` nằm ngoài khoảng 0–255.
- Biên dịch Java bằng JDK 21 thành công đối với toàn bộ mã nguồn ngoại trừ `SePayWebhookServer.java` (file này cần thư viện Jackson được khai báo trong Maven).

## Lưu ý về OperationsFrame
`OperationsFrame.java` hiện được dựng giao diện hoàn toàn bằng mã Java và không có file `OperationsFrame.form`. Vì vậy NetBeans không có biểu mẫu kéo-thả cho riêng JFrame này; đây không phải liên kết `.form` cũ mà là một màn hình chưa được chuyển sang GUI Builder. Không tạo một file `.form` rỗng giả vì sẽ khiến tab Design hiển thị sai giao diện thực tế.

## Nếu còn lỗi Color khi mở Design
Trong source và metadata hiện tại không phát hiện giá trị RGB literal sai. Nếu NetBeans vẫn báo `Color parameter outside of expected range`, cần lấy stack trace đầy đủ trong cửa sổ Output/IDE Log để xác định chính xác component hoặc NetBeans property editor phát sinh lỗi. Bản vá không tuyên bố đã kiểm chứng trực tiếp tab Design bên trong NetBeans IDE.
