# T&T Viet - cấu trúc mã nguồn

Mã nguồn Java được chia theo trách nhiệm:

- `ttviet.dao`: truy vấn và thao tác dữ liệu MySQL.
- `ttviet.controller`: điều phối điều hướng và xử lý luồng giữa các màn hình.
- `ttviet.model`: dữ liệu phiên đăng nhập và các đối tượng nghiệp vụ.
- `ttviet.view`: **chỉ chứa các JFrame**. File `.form` của NetBeans được đặt cạnh file `.java` tương ứng để mở tab Design.
- `ttviet.component`: JPanel, JDialog và các thành phần giao diện được nhúng vào JFrame.
- `ttviet.util`: kết nối cơ sở dữ liệu và tiện ích giao diện.
- `ttviet.payment`: tích hợp webhook thanh toán SePay.

## Quy tắc khi thêm màn hình/thành phần mới

- Màn hình cửa sổ độc lập (`JFrame`) đặt trong `ttviet.view`.
- Thành phần nhúng (`JPanel`) hoặc hộp thoại (`JDialog`) đặt trong `ttviet.component`.
- Không đặt DAO, model hoặc tiện ích xử lý dữ liệu trong package `view`.
- Với JFrame tạo bằng NetBeans GUI Builder, giữ cặp `TenFrame.java` và `TenFrame.form` cùng thư mục.
