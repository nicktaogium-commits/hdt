package ttviet;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import ttviet.view.LoginFrame;

/** Điểm khởi chạy ứng dụng T&T Viet. */
public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ex) { ex.printStackTrace(); }
            new LoginFrame().setVisible(true);
        });
    }
}
