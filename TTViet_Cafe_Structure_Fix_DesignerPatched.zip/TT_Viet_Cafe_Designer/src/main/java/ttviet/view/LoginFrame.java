package ttviet.view;


import ttviet.util.ResponsiveFrameSupport;
import ttviet.dao.AuthDAO;
import javax.swing.JOptionPane;
import java.beans.Beans;

/**
 * Form đăng nhập T&T Viet.
 * File LoginFrame.form đi kèm được NetBeans GUI Builder sử dụng ở tab Design.
 */
public class LoginFrame extends javax.swing.JFrame {

    //GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnLogin;
    private javax.swing.JCheckBox chkHienMatKhau;
    private javax.swing.JLabel lblPass;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUser;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
    //GEN-END:variables

    private char passwordEchoChar;

    public LoginFrame() {
        initComponents();
        passwordEchoChar = txtPassword.getEchoChar();
    }

    //GEN-BEGIN:initComponents
    private void initComponents() {
        lblTitle = new javax.swing.JLabel();
        lblUser = new javax.swing.JLabel();
        lblPass = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        chkHienMatKhau = new javax.swing.JCheckBox();
        btnLogin = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Đăng nhập - T & T Viet");
        setResizable(true);
        getContentPane().setBackground(new java.awt.Color(242, 248, 252));
        getContentPane().setLayout(null);

        lblTitle.setFont(new java.awt.Font("Serif", java.awt.Font.BOLD, 34));
        lblTitle.setForeground(new java.awt.Color(30, 112, 166));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("T & T VIET");
        lblTitle.setBounds(80, 30, 400, 55);
        getContentPane().add(lblTitle);

        lblUser.setForeground(new java.awt.Color(38, 55, 68));
        lblUser.setText("Tên đăng nhập");
        lblUser.setBounds(95, 145, 130, 28);
        getContentPane().add(lblUser);

        txtUsername.setText("admin");
        txtUsername.setBounds(230, 145, 230, 32);
        getContentPane().add(txtUsername);

        lblPass.setForeground(new java.awt.Color(38, 55, 68));
        lblPass.setText("Mật khẩu");
        lblPass.setBounds(95, 195, 130, 28);
        getContentPane().add(lblPass);

        txtPassword.setBounds(230, 195, 230, 32);
        getContentPane().add(txtPassword);

        chkHienMatKhau.setBackground(new java.awt.Color(242, 248, 252));
        chkHienMatKhau.setForeground(new java.awt.Color(38, 55, 68));
        chkHienMatKhau.setText("Hiện mật khẩu");
        chkHienMatKhau.addActionListener(evt -> chkHienMatKhauActionPerformed(evt));
        chkHienMatKhau.setBounds(230, 235, 230, 25);
        getContentPane().add(chkHienMatKhau);

        btnLogin.setBackground(new java.awt.Color(30, 112, 166));
        btnLogin.setForeground(java.awt.Color.WHITE);
        btnLogin.setText("ĐĂNG NHẬP");
        btnLogin.addActionListener(evt -> btnLoginActionPerformed(evt));
        btnLogin.setBounds(155, 285, 150, 40);
        getContentPane().add(btnLogin);

        btnExit.setBackground(new java.awt.Color(225, 241, 250));
        btnExit.setForeground(new java.awt.Color(25, 91, 135));
        btnExit.setText("THOÁT");
        btnExit.addActionListener(evt -> btnExitActionPerformed(evt));
        btnExit.setBounds(320, 285, 110, 40);
        getContentPane().add(btnExit);

        setSize(560, 410);
        setLocationRelativeTo(null);
        getRootPane().setDefaultButton(btnLogin);
        if (!Beans.isDesignTime()) {
            ResponsiveFrameSupport.install(this, 560, 410);
        }
    }
    //GEN-END:initComponents

    private void chkHienMatKhauActionPerformed(java.awt.event.ActionEvent evt) {
        if (chkHienMatKhau.isSelected()) {
            txtPassword.setEchoChar((char) 0);
        } else {
            txtPassword.setEchoChar(passwordEchoChar);
        }
    }

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập tên đăng nhập và mật khẩu.",
                    "Thiếu thông tin", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (AuthDAO.login(username, password)) {
            new OperationsFrame().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Sai tài khoản hoặc mật khẩu.",
                    "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {
        int answer = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc muốn thoát chương trình?",
                "Xác nhận thoát", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    /** Điểm chạy riêng để thử màn hình đăng nhập; toàn project vẫn chạy qua ttviet.App. */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
