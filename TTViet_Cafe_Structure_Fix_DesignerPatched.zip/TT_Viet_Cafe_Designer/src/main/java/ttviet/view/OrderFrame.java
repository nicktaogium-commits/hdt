package ttviet.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.beans.Beans;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ttviet.component.InvoiceDialog;
import ttviet.dao.OrderDAO;
import ttviet.util.DB;

/** Màn hình gọi món. Các thành phần giao diện được khai báo để NetBeans GUI Builder quản lý. */
public class OrderFrame extends JFrame {

    private DefaultTableModel model;
    private final NumberFormat money = NumberFormat.getNumberInstance(new Locale("vi", "VN"));

    public OrderFrame() {
        initComponents();
        configureVisuals();
        model = new DefaultTableModel(
            new Object[][] {}, new String[] {"Món", "Đơn giá", "Số lượng", "Thành tiền"}) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tblCart.setModel(model);
        spQty.setModel(new javax.swing.SpinnerNumberModel(1, 1, 99, 1));
        if (!Beans.isDesignTime()) {
            loadTables();
            loadProducts();
        }
    }

    /** Phần trang trí đặt ngoài mã do GUI Builder quản lý để tránh mất khi chỉnh Design. */
    private void configureVisuals() {
        getContentPane().setBackground(new Color(28, 28, 28));
        lblTitle.setFont(new Font("Arial", Font.BOLD, 25));
        lblTitle.setForeground(new Color(205, 160, 92));
        lblTable.setFont(new Font("Arial", Font.PLAIN, 14));
        lblTable.setForeground(Color.WHITE);
        lblProduct.setFont(new Font("Arial", Font.PLAIN, 14));
        lblProduct.setForeground(Color.WHITE);
        lblQty.setFont(new Font("Arial", Font.PLAIN, 14));
        lblQty.setForeground(Color.WHITE);
        tblCart.setRowHeight(32);
        tblCart.setFont(new Font("Arial", Font.PLAIN, 14));
        btnAdd.setBackground(new Color(169, 119, 58));
        btnAdd.setForeground(Color.WHITE);
        btnRemove.setBackground(new Color(75, 75, 82));
        btnRemove.setForeground(Color.WHITE);
        btnSave.setBackground(new Color(30, 112, 166));
        btnSave.setForeground(Color.WHITE);
        btnClose.setBackground(new Color(75, 75, 82));
        btnClose.setForeground(Color.WHITE);
        lblTotal.setFont(new Font("Arial", Font.BOLD, 21));
        lblTotal.setForeground(Color.WHITE);
    }

    //GEN-BEGIN:initComponents
    private void initComponents() {
        lblTitle = new javax.swing.JLabel();
        lblTable = new javax.swing.JLabel();
        cboTable = new javax.swing.JComboBox<>();
        lblProduct = new javax.swing.JLabel();
        cboProduct = new javax.swing.JComboBox<>();
        lblQty = new javax.swing.JLabel();
        spQty = new javax.swing.JSpinner();
        btnAdd = new javax.swing.JButton();
        scroll = new javax.swing.JScrollPane();
        tblCart = new javax.swing.JTable();
        lblTotal = new javax.swing.JLabel();
        btnRemove = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gọi món - T & T Viet");
        setResizable(true);
        setMinimumSize(new java.awt.Dimension(850, 580));
        getContentPane().setLayout(null);

        lblTitle.setText("GỌI MÓN / TẠO PHIẾU");
        getContentPane().add(lblTitle);
        lblTitle.setBounds(24, 18, 600, 42);

        lblTable.setText("Bàn:");
        getContentPane().add(lblTable);
        lblTable.setBounds(24, 82, 65, 34);

        getContentPane().add(cboTable);
        cboTable.setBounds(85, 82, 185, 34);

        lblProduct.setText("Món:");
        getContentPane().add(lblProduct);
        lblProduct.setBounds(286, 82, 65, 34);

        getContentPane().add(cboProduct);
        cboProduct.setBounds(330, 82, 390, 34);

        lblQty.setText("SL:");
        getContentPane().add(lblQty);
        lblQty.setBounds(735, 82, 35, 34);

        getContentPane().add(spQty);
        spQty.setBounds(770, 82, 65, 34);

        btnAdd.setText("THÊM MÓN");
        btnAdd.addActionListener(evt -> btnAddActionPerformed(evt));
        getContentPane().add(btnAdd);
        btnAdd.setBounds(850, 82, 126, 34);

        scroll.setViewportView(tblCart);
        getContentPane().add(scroll);
        scroll.setBounds(24, 140, 952, 420);

        lblTotal.setText("Tổng tạm tính: 0 đ");
        getContentPane().add(lblTotal);
        lblTotal.setBounds(24, 585, 470, 40);

        btnRemove.setText("XÓA MÓN");
        btnRemove.addActionListener(evt -> btnRemoveActionPerformed(evt));
        getContentPane().add(btnRemove);
        btnRemove.setBounds(570, 590, 110, 38);

        btnSave.setText("LƯU ĐƠN / IN PHIẾU");
        btnSave.addActionListener(evt -> btnSaveActionPerformed(evt));
        getContentPane().add(btnSave);
        btnSave.setBounds(695, 590, 170, 38);

        btnClose.setText("ĐÓNG");
        btnClose.addActionListener(evt -> btnCloseActionPerformed(evt));
        getContentPane().add(btnClose);
        btnClose.setBounds(880, 590, 96, 38);

        setSize(new java.awt.Dimension(1000, 680));
        setLocationRelativeTo(null);
    }
    //GEN-END:initComponents

    private void btnAddActionPerformed(ActionEvent evt) { addItem(); }
    private void btnRemoveActionPerformed(ActionEvent evt) { removeItem(); }
    private void btnSaveActionPerformed(ActionEvent evt) { saveOrder(); }
    private void btnCloseActionPerformed(ActionEvent evt) { dispose(); }

    private void loadTables() {
        cboTable.removeAllItems();
        try (Connection c = DB.getConnection(); Statement s = c.createStatement();
             ResultSet r = s.executeQuery("SELECT id,table_name FROM cafe_tables ORDER BY id")) {
            while (r.next()) cboTable.addItem(r.getInt(1) + " - " + r.getString(2));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải danh sách bàn: " + e.getMessage());
        }
    }

    private void loadProducts() {
        try (Connection c = DB.getConnection(); Statement s = c.createStatement();
             ResultSet r = s.executeQuery("SELECT name,price FROM products WHERE active=1 ORDER BY name")) {
            while (r.next()) cboProduct.addItem(r.getString(1) + " | " + r.getBigDecimal(2).toPlainString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải món: " + e.getMessage());
        }
    }

    private void addItem() {
        String value = (String) cboProduct.getSelectedItem();
        if (value == null) return;
        int split = value.lastIndexOf(" | ");
        if (split < 0) return;
        String name = value.substring(0, split);
        BigDecimal price = new BigDecimal(value.substring(split + 3));
        int quantity = (Integer) spQty.getValue();
        for (int i = 0; i < model.getRowCount(); i++) {
            if (name.equals(model.getValueAt(i, 0))) {
                int newQty = (Integer) model.getValueAt(i, 2) + quantity;
                model.setValueAt(newQty, i, 2);
                model.setValueAt(price.multiply(BigDecimal.valueOf(newQty)), i, 3);
                updateTotal();
                return;
            }
        }
        model.addRow(new Object[]{name, price, quantity, price.multiply(BigDecimal.valueOf(quantity))});
        updateTotal();
    }

    private void removeItem() {
        int row = tblCart.getSelectedRow();
        if (row >= 0) model.removeRow(tblCart.convertRowIndexToModel(row));
        updateTotal();
    }

    private void updateTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (int i = 0; i < model.getRowCount(); i++)
            total = total.add(new BigDecimal(model.getValueAt(i, 3).toString()));
        lblTotal.setText("Tổng tạm tính: " + money.format(total) + " đ");
    }

    private Integer selectedTableId() {
        String selected = (String) cboTable.getSelectedItem();
        if (selected == null || selected.endsWith(" - Mang đi")) return null;
        return Integer.valueOf(selected.substring(0, selected.indexOf(" - ")));
    }

    private void saveOrder() {
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Bạn chưa thêm món vào đơn.");
            return;
        }
        String table = String.valueOf(cboTable.getSelectedItem());
        int confirm = JOptionPane.showConfirmDialog(this,
            "Lưu đơn cho " + table + " với tổng tiền " + lblTotal.getText() +
            "?\nĐơn sẽ ở trạng thái CHỜ THANH TOÁN. In phiếu không có nghĩa là đã thu tiền.",
            "Xác nhận lưu đơn", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        long orderId = OrderDAO.saveAndGetId(model, selectedTableId());
        if (orderId > 0) {
            JOptionPane.showMessageDialog(this,
                "Đã lưu đơn ở trạng thái CHỜ THANH TOÁN. Thu ngân chỉ xác nhận đã thanh toán khi nhận được giao dịch hợp lệ.");
            new InvoiceDialog(this, orderId).setVisible(true);
            model.setRowCount(0);
            updateTotal();
        }
    }

    //GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox<String> cboProduct;
    private javax.swing.JComboBox<String> cboTable;
    private javax.swing.JLabel lblProduct;
    private javax.swing.JLabel lblQty;
    private javax.swing.JLabel lblTable;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JScrollPane scroll;
    private javax.swing.JSpinner spQty;
    private javax.swing.JTable tblCart;
    //GEN-END:variables
}
