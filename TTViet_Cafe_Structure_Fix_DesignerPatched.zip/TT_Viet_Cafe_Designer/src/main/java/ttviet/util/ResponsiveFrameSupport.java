package ttviet.util;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/** Keeps legacy NetBeans absolute-layout forms usable when the window is resized.
 * The original component positions remain editable in the NetBeans Design tab.
 */
public final class ResponsiveFrameSupport {
    private ResponsiveFrameSupport() { }

    public static void install(JFrame frame, int designWidth, int designHeight) {
        frame.setResizable(true);
        frame.setMinimumSize(new Dimension(Math.min(640, designWidth), Math.min(420, designHeight)));
        SwingUtilities.invokeLater(() -> {
            Map<Component, Rectangle> bounds = new LinkedHashMap<>();
            Map<Component, Font> fonts = new LinkedHashMap<>();
            for (Component component : frame.getContentPane().getComponents()) {
                bounds.put(component, component.getBounds());
                fonts.put(component, component.getFont());
            }
            frame.getContentPane().addComponentListener(new java.awt.event.ComponentAdapter() {
                private boolean updating;
                @Override public void componentResized(java.awt.event.ComponentEvent event) {
                    if (updating) return;
                    double sx = frame.getContentPane().getWidth() / (double) designWidth;
                    double sy = frame.getContentPane().getHeight() / (double) designHeight;
                    if (sx <= 0 || sy <= 0) return;
                    updating = true;
                    try {
                        for (Map.Entry<Component, Rectangle> entry : bounds.entrySet()) {
                            Component c = entry.getKey(); Rectangle b = entry.getValue();
                            c.setBounds((int)Math.round(b.x*sx), (int)Math.round(b.y*sy),
                                Math.max(1,(int)Math.round(b.width*sx)), Math.max(1,(int)Math.round(b.height*sy)));
                            Font f = fonts.get(c);
                            if (f != null) c.setFont(f.deriveFont((float)Math.max(9, Math.min(36, f.getSize2D()*Math.min(sx, sy)))));
                        }
                    } finally { updating = false; }
                }
            });
        });
    }
}
