package ttviet.controller;

import javax.swing.JFrame;
import ttviet.view.HistoryFrame;
import ttviet.view.LoginFrame;
import ttviet.view.MenuFrame;
import ttviet.view.OrderFrame;
import ttviet.view.TableFrame;

/** Điều hướng giữa các màn hình chính của ứng dụng. */
public final class NavigationController {
    private NavigationController() { }
    public static void openMenu(JFrame parent) { new MenuFrame().setVisible(true); }
    public static void openOrder(JFrame parent) { new OrderFrame().setVisible(true); }
    public static void openHistory(JFrame parent) { new HistoryFrame().setVisible(true); }
    public static void openTables(JFrame parent) { new TableFrame().setVisible(true); }
    public static void logout(JFrame parent) { new LoginFrame().setVisible(true); parent.dispose(); }
}
