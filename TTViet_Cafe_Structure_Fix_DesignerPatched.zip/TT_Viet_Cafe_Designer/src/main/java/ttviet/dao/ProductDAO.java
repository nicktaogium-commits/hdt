package ttviet.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ttviet.util.DB;

/** Truy vấn danh sách món đang kinh doanh. */
public class ProductDAO {
    public static DefaultTableModel load() {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Mã", "Tên món", "Nhóm", "Giá (VNĐ)"}, 0);
        String sql = "SELECT p.id, p.name, c.name, p.price "
                + "FROM products p JOIN categories c ON p.category_id = c.id "
                + "WHERE p.active = 1 ORDER BY p.id";

        try (Connection connection = DB.getConnection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            while (result.next()) {
                model.addRow(new Object[]{result.getInt(1), result.getString(2),
                    result.getString(3), result.getBigDecimal(4)});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
        }
        return model;
    }
}
