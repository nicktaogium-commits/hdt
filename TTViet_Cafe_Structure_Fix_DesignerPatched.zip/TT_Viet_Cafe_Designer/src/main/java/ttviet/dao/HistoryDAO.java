package ttviet.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ttviet.util.DB;

/** Truy vấn lịch sử đơn hàng. */
public class HistoryDAO {
    public static DefaultTableModel load() {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Mã đơn", "Thời gian", "Tổng tiền", "Trạng thái"}, 0);
        String sql = "SELECT order_code, created_at, total, status FROM orders ORDER BY id DESC";

        try (Connection connection = DB.getConnection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            while (result.next()) {
                model.addRow(new Object[]{result.getString(1), result.getTimestamp(2),
                    result.getBigDecimal(3), result.getString(4)});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
        }
        return model;
    }
}
