package ttviet.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ttviet.util.DB;

/** Truy vấn trạng thái bàn trong quán. */
public class TableDAO {
    public static DefaultTableModel load() {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Mã bàn", "Tên bàn", "Trạng thái"}, 0);
        String sql = "SELECT id, table_name, status FROM cafe_tables ORDER BY id";

        try (Connection connection = DB.getConnection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            while (result.next()) {
                model.addRow(new Object[]{result.getInt(1), result.getString(2), result.getString(3)});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
        }
        return model;
    }
}
